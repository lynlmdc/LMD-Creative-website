

$(document).ready(function(){

	$(function(){
		$("#main-nav li").hover(
		function(){
			$(">.sub-nav",this).slideDown(300);
		},
		function(){
			$(">.sub-nav",this).slideUp(300);
		});
	});


	$('div.p-nav').hover(
		function(){
			var thisItem = $(this).find('img')[0];
			$(thisItem).attr("src", "images/p-nav-on.svg");
		}, function(){
			var thisItem = $(this).find('img')[0];
			$(thisItem).attr("src", "images/p-nav-off.svg");
		}
	);


	function toggleMenu(){
		var displayValue = $(".nav-float").css("display");
		if(displayValue === "none"){
			$(".nav-float").slideDown();
		}	else {
			$(".nav-float").slideUp();
		}
	}

	$(".hamburger").click(toggleMenu);

	
});

